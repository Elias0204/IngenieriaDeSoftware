﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ProyectoIngenieriaDeSoftware.BLL;

namespace ProyectoIngenieriaDeSoftware.DAL
{
    internal class EmpleadosDAL
    {
        conexionDAL conexion;

        public EmpleadosDAL()
        {
            conexion = new conexionDAL();
        }

        //Este metodo agrega los registros que se escriban en los TextBox
        public bool Agregar(EmpleadosBLL oEmpleadosBLL)
        {
            SqlCommand SQLComando = new SqlCommand("INSERT INTO Empleados(nombres,primerapellido,segundoapellido,id_Departamento) VALUES(@Nombre,@pApellido,@sApellido,@Departamento)");
            SQLComando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = oEmpleadosBLL.Nombre;
            SQLComando.Parameters.Add("@pApellido", SqlDbType.VarChar).Value = oEmpleadosBLL.PrimerApellido;
            SQLComando.Parameters.Add("@sApellido", SqlDbType.VarChar).Value = oEmpleadosBLL.SegundoApellido;
            SQLComando.Parameters.Add("@Departamento", SqlDbType.VarChar).Value = oEmpleadosBLL.Departamento;

            return conexion.ejecutarComandoSinRetornoDatos(SQLComando);
        }

        public DataSet MostrarEmpleados()
        {
            SqlCommand sentencia = new SqlCommand("SELECT * FROM Empleados");
            return conexion.EjecutarSentencia(sentencia);
        }

        //Este metodo crea una instruccion para poder borrar los registros de las tablas
        public bool Eliminar(EmpleadosBLL oEmpleadosBLL)
        {
            SqlCommand SQLComando = new SqlCommand("DELETE FROM Empleados WHERE ID=@ID");
            SQLComando.Parameters.Add("@ID", SqlDbType.Int).Value = oEmpleadosBLL.ID;

            return conexion.ejecutarComandoSinRetornoDatos(SQLComando);
        }

        public bool Editar(EmpleadosBLL oEmpleadosBLL)
        {
            SqlCommand SQLComando = new SqlCommand("UPDATE Empleados SET nombres = '"+oEmpleadosBLL.Nombre+ "',primerapellido = '"+oEmpleadosBLL.PrimerApellido+ "',segundoapellido = '"+oEmpleadosBLL.SegundoApellido+ "',id_Departamento = '"+oEmpleadosBLL.Departamento+"' WHERE ID=@ID");
            SQLComando.Parameters.Add("@Nombre", SqlDbType.VarChar).Value = oEmpleadosBLL.Nombre;
            SQLComando.Parameters.Add("@pApellido", SqlDbType.VarChar).Value = oEmpleadosBLL.PrimerApellido;
            SQLComando.Parameters.Add("@sApellido", SqlDbType.VarChar).Value = oEmpleadosBLL.SegundoApellido;
            SQLComando.Parameters.Add("@id_Departamento", SqlDbType.VarChar).Value = oEmpleadosBLL.Departamento;
            SQLComando.Parameters.Add("@ID", SqlDbType.Int).Value = oEmpleadosBLL.ID;

            return conexion.ejecutarComandoSinRetornoDatos(SQLComando);
        }
    }
}
