﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoIngenieriaDeSoftware.DAL;
using ProyectoIngenieriaDeSoftware.BLL;

namespace ProyectoIngenieriaDeSoftware.PL
{
    public partial class frmEmpleados : Form
    {
        EmpleadosDAL oEmpleadosDAL;
        public frmEmpleados()
        {
            oEmpleadosDAL = new EmpleadosDAL();
            InitializeComponent();
            LLenarGrid();
            LimpiarEntradas();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void frmEmpleados_Load(object sender, EventArgs e)
        {
            DepartamentosDAL objDepartamentos = new DepartamentosDAL();

            cbxDepartamento.DataSource = objDepartamentos.MostrarDepartamentos().Tables[0];
            cbxDepartamento.DisplayMember = "departamento";
            cbxDepartamento.ValueMember = "ID";
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            oEmpleadosDAL.Agregar(RecuperarInformacion());
            LLenarGrid();
            LimpiarEntradas();
        }

        private EmpleadosBLL RecuperarInformacion()
        {
            EmpleadosBLL objEmpleados = new EmpleadosBLL();

            int codigoEmpleado = 1;
            int.TryParse(txtID.Text, out codigoEmpleado);

            objEmpleados.ID = codigoEmpleado;
            objEmpleados.Nombre = txtNombre.Text;
            objEmpleados.PrimerApellido = txtPrimerApellido.Text;
            objEmpleados.SegundoApellido = txtSegundoApellido.Text;

            int IDDepartamento = 0;
            int.TryParse(cbxDepartamento.SelectedValue.ToString(), out IDDepartamento);

            objEmpleados.Departamento = IDDepartamento;

            return objEmpleados;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Seleccionar(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indice = e.RowIndex;

            dgvEmpleados.ClearSelection();

            if (indice >=0)
            {
                txtID.Text = dgvEmpleados.Rows[indice].Cells[0].Value.ToString();
                txtNombre.Text = dgvEmpleados.Rows[indice].Cells[1].Value.ToString();
                txtPrimerApellido.Text = dgvEmpleados.Rows[indice].Cells[2].Value.ToString();
                txtSegundoApellido.Text = dgvEmpleados.Rows[indice].Cells[3].Value.ToString();
                cbxDepartamento.Text = dgvEmpleados.Rows[indice].Cells[4].Value.ToString();

                btnAceptar.Enabled = false;
                btnEditar.Enabled = true;
                btnEliminar.Enabled = true;
                btnCancelar.Enabled = true;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            oEmpleadosDAL.Eliminar(RecuperarInformacion());
            LLenarGrid();
            LimpiarEntradas();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            oEmpleadosDAL.Editar(RecuperarInformacion());
            LLenarGrid();
            LimpiarEntradas();
        }

        public void LLenarGrid()
        {
            dgvEmpleados.DataSource = oEmpleadosDAL.MostrarEmpleados().Tables[0];

            dgvEmpleados.Columns[0].HeaderText = "ID";
            dgvEmpleados.Columns[1].HeaderText = "Nombre";
            dgvEmpleados.Columns[2].HeaderText = "Primer Apellido";
            dgvEmpleados.Columns[3].HeaderText = "Segundo Apellido";
            dgvEmpleados.Columns[4].HeaderText = "ID_Departamento";
        }

        public void LimpiarEntradas()
        {
            txtID.Text = "";
            txtNombre.Text = "";
            txtPrimerApellido.Text = "";
            txtSegundoApellido.Text = "";
            cbxDepartamento.Text = "";

            btnAceptar.Enabled = true;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnCancelar.Enabled = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarEntradas();
        }
    }
}
